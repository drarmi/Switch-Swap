<?php
// User Form

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

include( ACFTC_PLUGIN_DIR_PATH . 'pro/location-helpers/user_form.php' );