<?php 
// ACF Color Palette Field
// https://github.com/7studio/acf-color-palette
// (Requires ACF PRO)

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

include( ACFTC_PLUGIN_DIR_PATH . 'render/radio.php' );
